const page1 = ({
  data,
  setPage
}) => {
  return /*#__PURE__*/React.createElement(Layout1, {
    data: data,
    setPage: setPage
  });
};
window.Page1 = page1;