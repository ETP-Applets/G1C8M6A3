const page8 = ({
  data,
  setPage,
  resetApplication
}) => {
  return /*#__PURE__*/React.createElement(Layout3, {
    data: data,
    setPage: setPage,
    resetApplication: resetApplication
  });
};
window.Page8 = page8;