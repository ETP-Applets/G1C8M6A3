const header = ({
  data
}) => {
  return /*#__PURE__*/React.createElement("div", {
    className: "text-[2.45vw] text-[#F9A942]"
  }, data.headers.title);
};
window.Header = header;