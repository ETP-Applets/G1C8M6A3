document.addEventListener('DOMContentLoaded', function() {
createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(StrictMode, null, /*#__PURE__*/React.createElement(window.App, null)));
});